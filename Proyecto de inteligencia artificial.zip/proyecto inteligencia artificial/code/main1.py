import sys
import json # Generar formatos en JSON para la respuesta
import numpy as np

class MedicalDiagnosticModule():
    def __init__( self ):
        #Matriz de valores
        self.preloadedmatrix = np.array(
            [
                [0.8, 0  , 0.6, 0  , 0.4, 0  , 0  , 0.6, 0.8, 0.7, 0.8, 0.6, 0  , 0  , 0  ],
                [0  , 0.6, 0.8, 0.8, 0.7, 0  , 0  , 0.4, 0.6, 0.5, 0.4, 0.7, 0  , 0  , 0.5],
                [0  , 0.8, 0.4, 0.7, 0.5, 0  , 0  , 0.7, 0  , 0.7, 0.5, 0  , 0  , 0.4, 0  ],
                [0  , 0.2, 0.9, 0.5, 0.7, 0.8, 0  , 0.4, 0  , 0  , 0.9, 0  , 0  , 0  , 0  ],
                [0  , 0  , 0.8, 0.3, 0.7, 0  , 0  , 0.7, 0.5, 0.7, 0.7, 0  , 0  , 0  , 0  ],
                [0.9, 0.6, 0.5, 0.4, 0.6, 0.9, 0  , 0.8, 0.7, 0.2, 0.8, 0.5, 0  , 0  , 0  ],
                [0  , 0  , 0.4, 0  , 0.7, 0  , 0  , 0.6, 0.9, 0.6, 0  , 0  , 0.8, 0  , 0.9],
                [0.7, 0.7, 0.8, 0.9, 0.5, 0.5, 0  , 0.6, 0.7, 0.4, 0.6, 0.6, 0  , 0.6, 0  ],
                [0  , 0  , 0.5, 0.6, 0.8, 0  , 0.8, 0.6, 0.9, 0.6, 0  , 0.8, 0  , 0  , 0  ],
                [0  , 0.6, 0.9, 0  , 0.6, 0  , 0  , 0.7, 0.9, 0.9, 0  , 0.8, 0  , 0  , 0  ]
            ] , dtype=np.float64 )
        self.intersectionmatrix = np.zeros( ( 10 , 16 ) , dtype=np.float64 )
        self.diagnosisresult = np.zeros( ( 1 , 10 ) , dtype=np.float64 )
        self.usersymptoms = []
        self.listdiseases = []

    def processARGV( self , matrix ):
        matrix = sys.argv[1] # Se recibe el argumento por la terminal
        # PROCESAMIENTO DEL STRING
        matrix = matrix.replace( ' ' , '' )
        matrix = matrix.replace( ' ' , '' )
        matrix = matrix.replace( '[[' , '' )
        matrix = matrix.replace( ']]' , '' )
        matrix = matrix.split( '],[' )
        try:
            # Generar un arreglo con la asignacion de sintomas
            self.usersymptoms = np.array( [matrix[0].split( ',' )] , dtype=np.float64 )
        except ValueError:
            print( '>VALUES CANNOT BE CONVERTED< (Symptom values are incorrect)' )
            exit()
        # Generar un arreglo con las enfermedades
        self.listdiseases = np.array( matrix[1].split( ',' ) )

    def generalDiagnosis( self ):
        # Se recorre el modulo de precarcado y lo compara con los sintomas recibidos 
        for i in range( 0 , self.preloadedmatrix.shape[0] ):
            for j in range( 0 , self.preloadedmatrix.shape[1] ):
                # Se guarda el resultado menor de la comparacion en la matriz de interseccion 
                if self.preloadedmatrix[i][j] >= self.usersymptoms[0][j]:
                    self.intersectionmatrix[i][j] = self.usersymptoms[0][j]
                else:
                    self.intersectionmatrix[i][j] = self.preloadedmatrix[i][j]
        # Se recorre la matriz de interseccion y se suman los valores para almacenarlos en la ultima posicion
        for i in range( 0 , self.intersectionmatrix.shape[0] ):
            for j in range( 0 , self.intersectionmatrix.shape[1]-1 ):
                self.intersectionmatrix[i][15] += self.intersectionmatrix[i][j]
            self.diagnosisresult[0][i] = self.intersectionmatrix[i][15]

    def specificDiagnosis( self ):
        # Se ejecuta la misma funcion
        self.generalDiagnosis()
        # Se eliminan los valores de las enfermedades que no se encuentran en la lista proveniente de la interfaz
        for i in range( 0 , 10 ):
            if str( i ) not in self.listdiseases:
                self.diagnosisresult[0][i] = -1
                
if __name__ == '__main__':
    mdm = MedicalDiagnosticModule()
    try:
        # Se conpruba que existan argumentos provenientes de la consola
        if len( sys.argv[1] ) > 1 :
            mdm.processARGV( sys.argv[1] )
    except IndexError:
        print( '>ARGUMENTS NOT RECEIVED<' )
        exit()
    # En caso de que la lista de enfermedades se encuentre vacia se ejecuta el diagnostico especifico
    if mdm.listdiseases[0] == '':
        try:
            mdm.generalDiagnosis()
        except IndexError:
            print( '>INVALID ARGUMENTS RECEIVED<' )
            exit()
    else:
        mdm.specificDiagnosis()
    print( json.dumps( mdm.diagnosisresult[0].tolist() ) )
